package com.example.myapplication;

public class Employee {
    public Integer empID;
    public String privateNumber;
    public String firstName;
    public String lastName;
    public String position;
    public int departmentId;
    public String department ;
}
