package com.example.myapplication;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class EmloyeeDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emloyee_detail);

        ImageView img = findViewById(R.id.image);
        String personalNumber = getIntent().getStringExtra("personalNumber");
//        Log.i("x", personalNumber);
        String url ="https://services.tbsg.ge/_test_timesheet/images/" + personalNumber + ".bmp";
        Picasso.with(this).load(url).into(img);
    }
}