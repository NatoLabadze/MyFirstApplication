package com.example.myapplication;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        new GetDataAsync().execute();


    }

    class GetDataAsync extends AsyncTask<String, String, ArrayList<Employee>> {

        @Override
        protected ArrayList<Employee> doInBackground(String... strings) {
            HttpClient httpClient = new HttpClient();
            String result = httpClient.httpGet("http://45.9.47.42:8735/api/Employees", null);

            ArrayList<Employee> employees = new ArrayList<>();

            try {
                JSONArray jsonArray = new JSONArray(result);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jObject = jsonArray.getJSONObject(i);

                    Employee employee = new Employee();
                    employee.empID = jObject.getInt("empID");
                    employee.firstName = jObject.getString("firstName");
                    employee.lastName = jObject.getString("lastName");
                    employee.privateNumber = jObject.getString("privateNumber");
                    employee.position = jObject.getString("position");
                    employee.departmentId = jObject.getInt("departmentId");
                    employee.department = jObject.getString("department");

                    employees.add(employee);
                }
            } catch (JSONException ex) {
                Toast.makeText(MainActivity.this, "წამოღება დასტულდა", Toast.LENGTH_SHORT).show();
            }
            return employees;
        }

        @Override
        protected void onPostExecute(final ArrayList<Employee> employees) {
            super.onPostExecute(employees);

            MyAdapter adapter = new MyAdapter(MainActivity.this, employees);
            listView.setAdapter(adapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(MainActivity.this, EmloyeeDetailActivity.class);
                    String selectedItem = employees.get(position).privateNumber;
                    intent.putExtra("personalNumber", selectedItem);
//                    Log.i("x", selectedItem);
                    startActivity(intent);

                }
            });

        }

        class MyAdapter extends BaseAdapter {
            Context context;
            ArrayList<Employee> employees;

            MyAdapter(Context context, ArrayList<Employee> employees) {
                this.context = context;
                this.employees = employees;
            }

            @Override
            public int getCount() {
                return employees.size();
            }

            @Override
            public Object getItem(int i) {
                return employees.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                LayoutInflater layoutInflater = (LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View row = layoutInflater.inflate(R.layout.row, parent, false);
                Employee currentEmployee = employees.get(position);

                ImageView images = row.findViewById(R.id.image);
                TextView empid = row.findViewById(R.id.empid);
                TextView firstname = row.findViewById(R.id.firstname);
                TextView lastname = row.findViewById(R.id.lastname);
                TextView privatenumber = row.findViewById(R.id.privatenumber);
                TextView positions = row.findViewById(R.id.positions);
                TextView department = row.findViewById(R.id.department);

                images.setImageResource(R.drawable.user1);
                empid.setText(currentEmployee.empID.toString());
                firstname.setText(currentEmployee.firstName);
                lastname.setText(currentEmployee.lastName);
                privatenumber.setText(currentEmployee.privateNumber);
                positions.setText(currentEmployee.position);
                department.setText(currentEmployee.department);


                return row;

            }
        }
    }
}